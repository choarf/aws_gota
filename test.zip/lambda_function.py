import json
import os
import boto3
import csv



def lambda_handler(event, context):
    bucket = 'ghotrix'
    action = event.get('action') # from gota raspi
    #key_csv = 'clientes/Lavadoras_Sur/gota001/key_sys/current_sys.csv' # S3 main record
    key_csv = 'test/test.csv' # S3 main record
    s3 = boto3.client('s3')
     # download s3 csv file to lambda tmp folder 
    local_file_name = '/tmp/test.csv' #
    s3.download_file(bucket, key_csv, local_file_name)   
    
        
 # write the data into '/tmp' folder
    with open('/tmp/test.csv','r') as infile:
        reader = list(csv.reader(infile))
        if len(reader) <= 1:
            reader[0] = event.keys()
        reader = reader[::-1] # the date is ascending order in file
        reader.insert(0,event.values())
    
    
    with open('/tmp/test.csv', 'w', newline='') as outfile:
        writer = csv.writer(outfile)
        for line in reversed(reader): # reverse order
            writer.writerow(line)
    
    # upload file from tmp to s3 key
    s3.upload_file(local_file_name, bucket, key_csv)

    
    
    # TODO implement
    print(event)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
